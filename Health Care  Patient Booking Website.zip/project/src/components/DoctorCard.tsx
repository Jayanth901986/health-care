import React from 'react';
import { User } from 'lucide-react';

interface DoctorCardProps {
  name: string;
  specialty: string;
  imageUrl: string;
}

export function DoctorCard({ name, specialty, imageUrl }: DoctorCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="h-48 w-full relative">
        {imageUrl ? (
          <img src={imageUrl} alt={name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-gray-200 flex items-center justify-center">
            <User className="h-20 w-20 text-gray-400" />
          </div>
        )}
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900">{name}</h3>
        <p className="text-sm text-gray-600">{specialty}</p>
      </div>
    </div>
  );
}