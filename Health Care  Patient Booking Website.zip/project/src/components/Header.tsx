import React from 'react';
import { Heart } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-white shadow-sm">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Heart className="h-6 w-6 text-blue-600" />
          <span className="text-xl font-semibold text-gray-900">HealthCare Plus</span>
        </div>
        <div className="flex space-x-6">
          <a href="#services" className="text-gray-600 hover:text-blue-600">Services</a>
          <a href="#doctors" className="text-gray-600 hover:text-blue-600">Doctors</a>
          <a href="#contact" className="text-gray-600 hover:text-blue-600">Contact</a>
        </div>
      </nav>
    </header>
  );
}